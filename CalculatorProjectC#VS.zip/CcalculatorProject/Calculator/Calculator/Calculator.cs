﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Calculator : Form
    {
        String screen = "";
        Double value1 = 0;
        Double value2 = 0;
        Double result = 0;
        char[] operatorArray = new char[] { '+', '-', '*', '/' };

        //screen.Contains(txbScreen.Text.Last())) // or if last character is a operator
        public Calculator()
        {
            InitializeComponent();
        }

        private void numberButton(int number)
        {
           screen = screen + number;
           updateScreenTxb();
        }

        private void operatorButton(String selectedOperator) {
            if (screen == "")
            { 
                return;
            }
            for (int i = 0; i < operatorArray.Length; i++) {
                if (screen.Contains(operatorArray[i])) {
                    MessageBox.Show("Calculator only supports one operand per calculation", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            screen = screen + selectedOperator;
            updateScreenTxb();
        }

        private void updateScreenTxb()
        {
            txbScreen.Text = screen;
        }
        

        private void btnAdd_Click(object sender, EventArgs e)
        {
            operatorButton("+");
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            operatorButton("-");
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            operatorButton("*");
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            operatorButton("/");
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < operatorArray.Length; i++)
            {
                if (screen.Contains(operatorArray[i]))
                {
                    try
                    {
                        var splitString = screen.Split(operatorArray[i]);
                        value1 = double.Parse(splitString[0]);
                        value2 = double.Parse(splitString[1]);
                    } catch {
                        MessageBox.Show("Please check your calculation.", "Syntax Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    
                    if (operatorArray[i] == '+'){
                        result = value1 + value2;
                    } 
                    if (operatorArray[i] == '-') {
                        result = value1 - value2;
                    }
                    if (operatorArray[i] == '*')
                    {
                        result = value1 * value2;
                    }
                    if (operatorArray[i] == '/')
                    {
                        result = value1 / value2;
                    }
                    screen = result.ToString();
                    updateScreenTxb();
                    break;
                }
            }
            
        }

        private void btnDecimalPoint_Click(object sender, EventArgs e)
        {
            if (screen == "" || screen.EndsWith("+") || screen.EndsWith("-") || screen.EndsWith("/") || screen.EndsWith("*") )
            {
                return;
            } else
            {
                screen = screen + ".";
                updateScreenTxb();
            }
        }

        private void btnNum1_Click(object sender, EventArgs e)
        {
            numberButton(1);
        }
        private void btnNum2_Click(object sender, EventArgs e)
        {
            numberButton(2);
        }

        private void btnNum3_Click(object sender, EventArgs e)
        {
            numberButton(3);
        }

        private void btnNum4_Click(object sender, EventArgs e)
        {
            numberButton(4);
        }

        private void btnNum5_Click(object sender, EventArgs e)
        {
            numberButton(5);
        }

        private void btnNum6_Click(object sender, EventArgs e)
        {
            numberButton(6);
        }

        private void btnNum7_Click(object sender, EventArgs e)
        {
            numberButton(7);
        }

        private void btnNum8_Click(object sender, EventArgs e)
        {
            numberButton(8);
        }

        private void btnNum9_Click(object sender, EventArgs e)
        {
            numberButton(9);
        }

        private void btnNum0_Click(object sender, EventArgs e)
        {
            numberButton(0);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            screen = "";
            updateScreenTxb();
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (screen == "")
            {
                return;
            } else
            {
                screen = screen.Remove(screen.Length - 1, 1);
                updateScreenTxb();
            }
            
        }

        private void btnLoadAnswer_Click(object sender, EventArgs e)
        {
            screen = result.ToString();
            updateScreenTxb();
        }
    }
}
